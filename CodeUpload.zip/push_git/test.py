import pyautogui
import clipboard
import os 
import win32api

from pathlib import Path
import shutil

def upload():
    pyautogui.click(position["github"])
    pyautogui.sleep(1)
    pyautogui.click(position["commit_text"])
    pyautogui.sleep(1)
    pyautogui.typewrite("up1")
    pyautogui.sleep(1)
    pyautogui.click(position["commit_button"])
    pyautogui.sleep(1)
    while pyautogui.locateOnScreen("D:\\AI_VSCode\\push_git\\img\\commiting.png"):
        print("commiting")
        pyautogui.sleep(1)
    pyautogui.hotkey('ctrl','p')
    pyautogui.sleep(1)
    while pyautogui.locateOnScreen("D:\\AI_VSCode\\push_git\\img\\pushing_1.png"):
        print("pushing")
        pyautogui.sleep(1)
    # pyautogui.hotkey("alt" + "tab")


#đăng nhập 
def sign_out():
    pyautogui.sleep(1)
    pyautogui.click(position["chrome"])    
    pyautogui.sleep(1)
    pyautogui.click(position["account"])
    pyautogui.sleep(0.5)
    pyautogui.click(position["sign_out_web"])
    pyautogui.sleep(2)
    pyautogui.click(position["auth"])
    pyautogui.hotkey('win','d')
    pyautogui.sleep(0.5)

#đăng nhập 
def sign_in(acc):
    pyautogui.click(position["github"])
    pyautogui.sleep(1)
    pyautogui.hotkey('ctrl',',')
    pyautogui.sleep(1)
    pyautogui.click(position["sign_out"])
    pyautogui.sleep(1)
    pyautogui.click(position["sign_out"])
    pyautogui.sleep(1)
    pyautogui.hotkey('enter')
    while not pyautogui.locateOnScreen("D:\\AI_VSCode\\push_git\\img\\sign_in_git.png"):
        pyautogui.sleep(1)
        print("wait")
    pyautogui.typewrite(acc[0])
    pyautogui.hotkey('tab')
    pyautogui.typewrite(acc[1])
    pyautogui.hotkey('enter')
    pyautogui.sleep(5)
    pyautogui.hotkey('win','d')
def swich_acc(acc):
    sign_out()
    sign_in(acc)
    pyautogui.sleep(2)
    pyautogui.click(position['chrome'])
    pyautogui.sleep(1)
    pyautogui.hotkey('ctrl','w')
    pyautogui.press('f5')
    pyautogui.sleep(5)
    pyautogui.hotkey('win','d')


position={
    'github':[1015,1050],
    'folder':[1070,1050],
    'chrome':[1185,1050],
    'commit_text':[450,700],
    'commit_button':[500,900],
    'sign_out':[1260,356],
    'account':[1845,130],
    'sign_out_web':[1755,895],
    'auth':[900,430],
    'publish':[719,588]
}

ACCOUNT_LIST = [[r'a40355@gmail.com','trong1011','Trong112002'],
                [r'kaidodo001@gmail.com','trong1011','manga001'],
                [r'kaidodo002@gmail.com','trong1011','manga002'],
                [r'kaidodo003@gmail.com','trong1011','manga004'],
                [r'kaidodo004@gmail.com','trong1011','manga005'],
                [r'kaidodo005@gmail.com','trong1011','manga008'],
                [r'kaidodo008@gmail.com','trong1011','manga012'],
                [r'phucdongjasmarkets@gmail.com','trong1011','manga013'],
                [r'kaidodo009@gmail.com','trong1011','manga014'],
                [r'kaidodo0010@gmail.com','trong1011','manga015'],
                [r'kaidodo0011@gmail.com','trong1011','manga016'],
                [r'kaidodo0012@gmail.com','trong1011','manga017'],
                [r'kaidodo0013@gmail.com','trong1011','manga018'],
                [r'kaidodo16@gmail.com','trong1011','manga019'],
                [r'kaidodo14@gmail.com','trong1011','manga021'],
                [r'kaidodo18@gmail.com','trong1011','manga023'],
                [r'kaidodo19@gmail.com','trong1011','manga024'],
                [r'kaidodo22@gmail.com','trong1011','manga025'],
                [r'kaidodo24@gmail.com','trong1011','manga026'],
                [r'kaidodo29@gmail.com','trong1011','manga027']
                ]

# shutil.copytree(r"F:\data\mangainn.net\+Tic Neesan\+Tic Neesan - 1",r"E:\GitOnComp\manga_data1\+Tic Neesan\+Tic Neesan - 1")
# upload()
for i in ACCOUNT_LIST:
    swich_acc(i)
    print(i[2])
# sign_out()
# sign_in(account_list[1])
# create_repo('test')

def create_repo(name):
    pyautogui.click(position["github"])
    pyautogui.sleep(0.5)
    pyautogui.hotkey('ctrl','n')
    pyautogui.sleep(0.5)
    pyautogui.typewrite(name)
    pyautogui.hotkey('enter')
    while pyautogui.locateOnScreen("D:\\AI_VSCode\\push_git\\img\\creating_repo.png"):
        pyautogui.sleep(1)
        print("waiting")
    pyautogui.sleep(1)
    pyautogui.hotkey('ctrl','p')
    pyautogui.sleep(1) 
    pyautogui.click(position['publish'])
    pyautogui.sleep(1)
    pyautogui.hotkey('enter')
    while pyautogui.locateOnScreen("D:\\AI_VSCode\\push_git\\img\\publishing.png"):
        pyautogui.sleep(1)
        print("publishing")
    pyautogui.sleep(7)
    pyautogui.hotkey('ctrl','shift','f')
    pyautogui.sleep(0.5)
    pyautogui.hotkey('ctrl','l')
    pyautogui.sleep(0.2)
    pyautogui.hotkey('ctrl','c')
    pyautogui.sleep(0.2)
    pyautogui.hotkey('alt','f4')
    path = clipboard.paste()
    path = path.replace("\\","\\\\")
    # pyautogui.hotkey('win','d')
    return path

# print(create_repo("abc"))