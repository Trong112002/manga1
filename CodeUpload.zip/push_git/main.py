import pyautogui
import os
import shutil
import clipboard
import re
import requests
from bs4 import BeautifulSoup
import json 

#Các tham số ban đầu 




#Hàm tính kích thước folder
def get_folder_size(folder_path):
    total_size = 0

    # Kiểm tra xem folder_path có tồn tại không
    if os.path.exists(folder_path) and os.path.isdir(folder_path):
        # Lặp qua tất cả các tệp và thư mục trong folder_path
        for path, dirs, files in os.walk(folder_path):
            for file in files:
                # Lấy thông tin kích thước của từng tệp
                file_path = os.path.join(path, file)
                total_size += os.path.getsize(file_path)
    return total_size/1024/1024 #mb

#Hàm đếm số lượng file con 
def count_files(folder_path):
    file_count = 0
    for root, dirs, files in os.walk(folder_path):
        file_count += len(files)
    return file_count

#Tạo repo
def create_repo(name):
    pyautogui.click(POSITION["github"])
    pyautogui.sleep(0.5)
    pyautogui.hotkey('ctrl','n')
    pyautogui.sleep(0.5)
    pyautogui.typewrite(name)
    pyautogui.hotkey('enter')
    while pyautogui.locateOnScreen("D:\\AI_VSCode\\push_git\\img\\creating_repo.png"):
        pyautogui.sleep(1)
        print("waiting")
    pyautogui.sleep(1)
    pyautogui.hotkey('ctrl','p')
    pyautogui.sleep(1) 
    pyautogui.click(POSITION['publish'])
    pyautogui.sleep(1)
    pyautogui.hotkey('enter')
    pyautogui.sleep(10)
    pyautogui.hotkey('ctrl','shift','f')
    pyautogui.sleep(0.5)
    pyautogui.hotkey('ctrl','l')
    pyautogui.sleep(0.2)
    pyautogui.hotkey('ctrl','c')
    pyautogui.sleep(0.2)
    pyautogui.hotkey('alt','f4')
    path = clipboard.paste()
    path = path.replace("\\","\\\\")
    pyautogui.hotkey('win','d')
    return path

#đăng xuất ở app
def sign_out():
    pyautogui.click(POSITION["chrome"])    
    pyautogui.sleep(1)
    pyautogui.click(POSITION["account"])
    pyautogui.sleep(0.5)
    pyautogui.click(POSITION["sign_out_web"])
    pyautogui.sleep(2)
    pyautogui.click(POSITION["auth"])
    pyautogui.hotkey('win','d')
    pyautogui.sleep(0.5)

#đăng nhập 
def sign_in(acc):
    pyautogui.click(POSITION["github"])
    pyautogui.hotkey('ctrl',',')
    pyautogui.sleep(1)
    pyautogui.click(POSITION["sign_out"])
    pyautogui.sleep(1)
    pyautogui.click(POSITION["sign_out"])
    pyautogui.sleep(1)
    pyautogui.hotkey('enter')
    while not pyautogui.locateOnScreen("D:\\AI_VSCode\\push_git\\img\\sign_in_git.png"):
        pyautogui.sleep(1)
        print("wait")
    pyautogui.typewrite(acc[0])
    pyautogui.hotkey('tab')
    pyautogui.typewrite(acc[1])
    pyautogui.hotkey('enter')
    pyautogui.sleep(1)
    pyautogui.hotkey('win','d')
def swich_acc(acc):
    sign_out()
    sign_in(acc)
    pyautogui.sleep(2)
    pyautogui.click(POSITION['chrome'])
    pyautogui.sleep(1)
    pyautogui.hotkey('ctrl','w')
    pyautogui.press('f5')
    pyautogui.sleep(2)
    pyautogui.hotkey('win','d')

#Tải file
def upload():
    pyautogui.sleep(1)
    pyautogui.hotkey('win','d')
    pyautogui.click(POSITION["github"])
    while pyautogui.locateOnScreen("D:\\AI_VSCode\\push_git\\img\\wait_commit.png"):
        print("waiting")
        pyautogui.sleep(1)
    pyautogui.sleep(0.5)
    pyautogui.click(POSITION["commit_text"])
    pyautogui.sleep(0.2)
    pyautogui.typewrite("up")
    pyautogui.sleep(0.5)
    pyautogui.click(POSITION["commit_button"])
    while pyautogui.locateOnScreen("D:\\AI_VSCode\\push_git\\img\\commiting.png"):
        print("commiting")
        pyautogui.sleep(1)
    pyautogui.hotkey('ctrl','p')
    while pyautogui.locateOnScreen("D:\\AI_VSCode\\push_git\\img\\pushing_1.png"):
        print("pushing")
        pyautogui.sleep(1)
    pyautogui.hotkey('win','d')
    print("Upload succcess")

#Lấy đường dẫn hiện tại 
def get_trg_path_now():
    pyautogui.hotkey('win','d')
    pyautogui.click(POSITION['github'])
    pyautogui.hotkey('ctrl','shift','f')
    pyautogui.sleep(1)
    pyautogui.hotkey('ctrl','l')
    pyautogui.sleep(1)
    pyautogui.hotkey('ctrl','c')
    pyautogui.sleep(1)
    pyautogui.hotkey('alt','f4')
    pyautogui.sleep(1)
    pyautogui.hotkey('win','d')
    pyautogui.sleep(1)
    path = clipboard.paste()
    path = path.replace("\\","\\\\")
    return path

def crawl_mangainn(link):
    # https://www.mangainn.net/tales-of-demons-and-gods/416.5/all-pages
    href = link.split("/")[0:4]
    chapter = link.split("/")[4]
    href = "/".join(href)
    response = requests.get(link)
    content = response.text.encode('utf-8')
    soup = BeautifulSoup(content, 'html.parser')
    a_tag = soup.find('a',href = href)
    content = a_tag.text
    return content + r"\\" + content + " - " + chapter 

def crawl_mangajar(link):
    # https://mangajar.com/manga/3-gatsu-no-lion/chapter/201
    href = link.split(".com")[1]
    href = href.split("/")[0:3]
    chapter = href.split("/")[4]
    href = "/".join(href)
    response = requests.get(link)
    content = response.text.encode('utf-8')
    soup = BeautifulSoup(content, 'html.parser')
    a_tag = soup.find('a',href = href)
    content = a_tag.text
    return content + r"\\" + "Chapter "+ chapter

def crawl_ninemanga(link):
    href = link.split(".com")[1]
    response = requests.get(link)
    content = response.text.encode('utf-8')
    soup = BeautifulSoup(content, 'html.parser')

    # Tìm thẻ <a> trong đoạn mã HTML
    a_tag = soup.find('a',href = href)

    # Lấy nội dung của thẻ <a>
    content = a_tag.text
    content = content.split(" ")
    content = content[:-2]
    content = " ".join(content)
    return content

def crawl_manganelo(link):
    # https://ww5.manganelo.tv/chapter/manga-jw987305/chapter-74.6
    href = link.split(".tv")[1]
    response = requests.get(link)
    content = response.text.encode('utf-8')
    soup = BeautifulSoup(content, 'html.parser')

    # Tìm thẻ <a> trong đoạn mã HTML
    a_tag = soup.find('a',href = href)

    # Lấy nội dung của thẻ <a>
    content = a_tag.text
    content = content.split(" ")
    content = content[:-2]
    content = " ".join(content)
    return content

def crawl_mangakomi(link):
    # https://mangakomi.io/manga/hatarakanai-futari-yoshida-satoru/chapter-1260/
    id = "chapter-heading"
    response = requests.get(link)
    content = response.text
    soup = BeautifulSoup(content, 'html.parser')
    heading = soup.find(id = id)
    content = heading.text
    content = content.replace(" - ",r"\\")
    return content

def crawl_manganelo(link):
    # https://ww5.manganelo.tv/chapter/manga-jw987305/chapter-74.6
    response = requests.get(link)
    content = response.text
    soup = BeautifulSoup(content, 'html.parser')
    name,chapter = soup.find_all(class_="a-h")[1:3]
    name,chapter = name.text,chapter.text
    return name + r"\\" + chapter 

def crawl_mto(link):
    value = link.split("/")[-1]
    response = requests.get(link)
    content = response.text
    soup = BeautifulSoup(content, 'html.parser')
    h3 = soup.find('h3',class_ = 'nav-title')
    a = h3.find('a')
    select = soup.find('option', value = value)
    return a.text +r"\\"+ " ".join(select.text.split())

def crawl_readm(link):
    # https://readm.org//manga/19468/123/all-pages
    href ="/" + "/".join(link.split("/")[4:6])
    response = requests.get(link)
    content = response.text
    soup = BeautifulSoup(content, 'html.parser')
    name = soup.find('a',href = href).text
    name = " ".join(name.split())
    chapter = soup.find(class_ = 'light-title').text
    return " ".join((name + r"\\" + chapter).split())

def process_text(link1):
    link = link1.replace("https://","")
    link = link.replace("www.","")
    link = link.replace("ww5.","")
    web,link = link.split("/",1)
    if web == "mangareader.cc":
        # https://mangareader.cc/chapter/rise-from-the-rubble-chapter-149
        link = link.split("/")[1]
        link = link.split("-")
        name = " ".join(link[:-2])
        chapter = " ".join(link[-2:])
        return web + r"\\" + name + r"\\" + chapter
    elif web == "readm.org":
        # https://readm.org//manga/19468/123/all-pages
        name = crawl_readm(link1)
        return web + r"\\" + name
    elif web == "manganelo.tv":
        #https://ww5.manganelo.tv/chapter/manga-jw987305/chapter-74.6
        name = crawl_manganelo(link1)
        return web + r"\\" + name
    
    elif web == "ninemanga.com":
        # https://www.ninemanga.com/chapter/SHEN%20YIN%20WANG%20ZUO/7385436.html
        name = link.split("/")[1]
        name = name.replace("%20"," ")
        chapter = crawl_ninemanga(link1)
        return web + r"\\" + name + r"\\" + chapter
    elif web == "mangakomi.io":
        # https://mangakomi.io/manga/hatarakanai-futari-yoshida-satoru/chapter-1260/
        name = crawl_mangakomi(link1)
        return web +r"\\" + name
    elif web == "mangainn.net":
        #https://www.mangainn.net/tales-of-demons-and-gods/416.5/all-pages
        name = crawl_mangainn(link1)
        return web +r"\\" + name
    elif web == "br.ninemanga.com":
        pass
    elif web == "de.ninemanga.com":
        # https://de.ninemanga.com/chapter/Solo%20Leveling/450993.html
        name = link.split("/")[1]
        name = name.replace("%20"," ")
        chapter = crawl_ninemanga(link1)
        return web + r"\\" + name + r"\\" + chapter
    elif web == "es.ninemanga.com":
        try:
            name = link.split("/")[1]
            name = name.replace("%20"," ")
            chapter = crawl_ninemanga(link1)
            return web + r"\\" + name + r"\\" + chapter
        except:
            pass
    elif web == "fr.ninemanga.com":
        name = link.split("/")[1]
        name = name.replace("%20"," ")
        chapter = crawl_ninemanga(link1)
        return web + r"\\" + name + r"\\" + chapter
    elif web == "it.ninemanga.com":
        name = link.split("/")[1]
        name = name.replace("%20"," ")
        chapter = crawl_ninemanga(link1)
        return web + r"\\" + name + r"\\" + chapter
    elif web == 'ru.ninemanga.com':
        name = link.split("/")[1]
        name = name.replace("%20"," ")
        chapter = crawl_ninemanga(link1)
        return web + r"\\" + name + r"\\" + chapter
    elif web == "mto.to":
        # https://mto.to/chapter/1606924
        name = crawl_mto(link1)
        return web + r"//" + name
    elif web == "mangajar.com":
        # https://mangajar.com/manga/fff-class-trashero-abs301K/chapter/108
        name = crawl_mangajar(link1)
        return web + r"\\" + name
    elif web == "swatmanga.net":
        # https://swatmanga.net/1381041/s-back-to-rule-again-free-235/
        pass
    else:
        print("web not exist")

def get_name_manga(text):
    text = text.split(r"\\")
    return text[-2:-1][0]

def get_chapter_manga(text):
    text = text.split(r"\\")
    return text[-1:][0]

def get_link(acc,repo,url,len):
    url = url.split("\\")[-2:]
    url = "/".join(url)
    list = []
    for i in range(1,len+1):    
        link = "https://github.com/" + str(acc) +"/"+ str(repo) + "/blob/main/" + url + "/" + str(i) + ".jpg?raw=true" 
        link = re.sub(r"\s","%20",link)
        list.append(link)
    return list

POSITION={
    'github':[1015,1050],
    'folder':[1070,1050],
    'chrome':[1185,1050],
    'commit_text':[450,700],
    'commit_button':[500,900],
    'sign_out':[1260,356],
    'account':[1845,130],
    'sign_out_web':[1755,895],
    'auth':[900,430],
    'publish':[719,588]
}

DATA_PATH = "F:\\data\\"
REPO_NAME = []
#Tạo danh sách tên repo
for i in range(1,51):
    row = []
    for j in range(1,21):
        row.append(f"manga_{i}_{j}")
    REPO_NAME.append(row)
SIZE_NOW = 0
REPO_NOW = 0
ACC_NOW = 0
COUNT_FILE = 0
GIT_LOCAL_PATH = create_repo(REPO_NAME[REPO_NOW][ACC_NOW])
ACCOUNT_LIST = [[r'a40355@gmail.com','trong1011','Trong112002'],
                [r'kaidodo001@gmail.com','trong1011','manga001'],
                [r'kaidodo002@gmail.com','trong1011','manga002'],
                [r'kaidodo003@gmail.com','trong1011','manga004'],
                [r'kaidodo004@gmail.com','trong1011','manga005'],
                [r'kaidodo005@gmail.com','trong1011','manga008'],
                [r'kaidodo008@gmail.com','trong1011','manga012'],
                [r'phucdongjasmarkets@gmail.com','trong1011','manga013'],
                [r'kaidodo009@gmail.com','trong1011','manga014'],
                [r'kaidodo0010@gmail.com','trong1011','manga015'],
                [r'kaidodo0011@gmail.com','trong1011','manga016'],
                [r'kaidodo0012@gmail.com','trong1011','manga017'],
                [r'kaidodo0013@gmail.com','trong1011','manga018'],
                [r'kaidodo16@gmail.com','trong1011','manga019'],
                [r'kaidodo14@gmail.com','trong1011','manga021'],
                [r'kaidodo18@gmail.com','trong1011','manga023'],
                [r'kaidodo19@gmail.com','trong1011','manga024'],
                [r'kaidodo22@gmail.com','trong1011','manga025'],
                [r'kaidodo24@gmail.com','trong1011','manga026'],
                [r'kaidodo29@gmail.com','trong1011','manga027']
                ]

# mở file json
with open(r"D:\AI_VSCode\push_git\sssss.json",'r',encoding='utf-8') as inputfile:
    data = json.load(inputfile)

# đọc qua từng dòng và ghi lại link
for row in data:
    try:
        link = row['id_chapter'] 
        #Tham chiếu sang folder
        path_to_chapter = DATA_PATH + process_text(link)
        if not os.path.exists(path_to_chapter):
            print("not exist")
            row['list_link_image'] = ""
            with open("result.json", "w") as json_file:
                json.dump(data, json_file, indent = 4)
            continue

        name_manga = get_name_manga(process_text(link))
        name_chapter = get_chapter_manga(process_text(link))

        trg_path = GIT_LOCAL_PATH + "\\" + name_manga + "\\" +  name_chapter
        if os.path.exists(trg_path):
            shutil.rmtree(trg_path)
        print(trg_path)
        
        shutil.copytree(path_to_chapter,trg_path)
        COUNT_FILE += count_files(path_to_chapter)
        print("Count: ",COUNT_FILE)
        if COUNT_FILE > 200:
            upload()
            COUNT_FILE = 0
            # Nếu repo >9000mb đổi repo
            if SIZE_NOW >= 9000:
                try:
                    os.system('rmdir /S /Q "{}"'.format(GIT_LOCAL_PATH))
                    if os.system('rmdir /S /Q "{}"'.format(GIT_LOCAL_PATH)):
                        print("Delete folder success")
                except:
                    print("Delete folder fail")
                # Nếu == 50 repo thì đổi tài khoản
                if REPO_NOW == 50:
                    swich_acc(ACCOUNT_LIST[ACC_NOW])
                    ACC_NOW+=1
                    REPO_NOW = 0
                REPO_NOW += 1
                GIT_LOCAL_PATH = create_repo(REPO_NAME[REPO_NOW][ACC_NOW])
                SIZE_NOW = 0
        print(SIZE_NOW)
        url_git = name_manga + "/" + name_chapter
        # Thêm danh sách link tới ảnh        
        row['list_link_image'] = get_link(ACCOUNT_LIST[ACC_NOW][2],REPO_NAME[REPO_NOW][ACC_NOW],url_git,count_files(path_to_chapter))

        # Tính size của repo
        SIZE_NOW += get_folder_size(path_to_chapter)
        
        # Ghi vào file json 
        with open("result.json", "w") as json_file:
            json.dump(data, json_file, indent = 4)
    except:
        print("error 1")